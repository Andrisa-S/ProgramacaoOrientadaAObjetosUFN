package exemp2;

abstract class Forma {
	public abstract double area();
	public abstract double perimetro();
}
