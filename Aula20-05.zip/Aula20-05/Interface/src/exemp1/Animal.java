package exemp1;

public interface Animal {
	int constante = 7; //Apenas constantes inicializadas são permitidas
	void emitirSom();
	void exibirDados();
}
