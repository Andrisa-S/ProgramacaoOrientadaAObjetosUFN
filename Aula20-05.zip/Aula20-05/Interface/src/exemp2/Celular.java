package exemp2;

interface Celular {
	public void realizarChamada();
}
