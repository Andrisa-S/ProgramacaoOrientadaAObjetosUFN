package exemp2;

interface PC {
	public void verificaEmail();
}
