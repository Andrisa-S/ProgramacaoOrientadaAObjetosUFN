package exemp2;

public class Principal {

	public static void main(String[] args) {
		Smartphone s = new Smartphone("9910", "andss");
		
		s.verificaEmail();
		s.realizarChamada();
	}

}
